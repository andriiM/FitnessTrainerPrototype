//
//  main.m
//  Trainer
//
//  Created by andrii on 27.03.12.
//  Copyright (c) 2012 limeapps. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TrainerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TrainerAppDelegate class]));
    }
}
