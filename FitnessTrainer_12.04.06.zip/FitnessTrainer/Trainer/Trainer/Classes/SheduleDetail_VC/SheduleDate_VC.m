//
//  SheduleDate_VC.m
//  Trainer
//
//  Created by andrii on 28.03.12.
//  Copyright (c) 2012 limeapps. All rights reserved.
//

#import "SheduleDate_VC.h"

@implementation SheduleDate_VC

- (void)viewDidLoad{
    [super viewDidLoad];
    [self setTitle:@"Shedule"];
}


#pragma mark - Memory management

- (void)viewDidUnload{
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

@end
