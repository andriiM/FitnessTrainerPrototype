//
//  YourGoals_VC.h
//  Trainer
//
//  Created by andrii   on 29.03.12.
//  Copyright (c) 2012 limeapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YourGoals_VC : UITableViewController{
    NSMutableDictionary *goals;
}

@end
