//
//  Log_VC.h
//  FitnessTrainer
//
//  Created by andrii on 28.03.12.
//  Copyright (c) 2012 limeapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Log_VC : UIViewController{
    IBOutlet UITableView *table;
}

@end
